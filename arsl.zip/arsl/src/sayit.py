#!/usr/bin/python3

import rospy
from std_msgs.msg import String
from google.cloud import texttospeech
import os
from playsound import playsound

# Set the environment variable for Google Credentials
#os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'text-to-speech-435015-82e32527fb00.json'
#export GOOGLE_APPLICATION_CREDENTIALS="/home/tharindu/arsl_ws/src/arsl/src/text-to-speech-435015-82e32527fb00.json"
#os.system("export GOOGLE_APPLICATION_CREDENTIALS='/home/tharindu/arsl_ws/src/arsl/src/text_to_speech_435015_82e32527fb00.json'")

class TTSSubscriber:
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('textToSpeech', anonymous=True)
        
        # Create a subscriber
        self.subscriber = rospy.Subscriber('gesture_label', String, self.callback)

        # Initialize Text-to-Speech client
        self.client = texttospeech.TextToSpeechClient()

    def callback(self, msg):
        rospy.loginfo(f"Received message: {msg.data}")
        self.synthesize_speech(msg.data)

    def synthesize_speech(self, text):
        # Set up the synthesis request
        input_text = texttospeech.SynthesisInput(text=text)
        voice = texttospeech.VoiceSelectionParams(
            language_code='ar-XA',
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )

        # Perform the text-to-speech request
        response = self.client.synthesize_speech(
            input=input_text, voice=voice, audio_config=audio_config
        )

        # Save the audio file
        output_file = 'output.mp3'
        with open(output_file, 'wb') as out:
            out.write(response.audio_content)
            rospy.loginfo(f'Audio content written to file {output_file}')

        # Play the audio
        playsound(output_file)

if __name__ == '__main__':
    try:
        TTSSubscriber()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

